<?php
/**
 * @package rocketgallery
 */
require_once (strtr(realpath(dirname(dirname(__FILE__))), '\\', '/') . '/rocketgalleryset.class.php');
class RocketGallerySet_mysql extends RocketGallerySet {}
?>
