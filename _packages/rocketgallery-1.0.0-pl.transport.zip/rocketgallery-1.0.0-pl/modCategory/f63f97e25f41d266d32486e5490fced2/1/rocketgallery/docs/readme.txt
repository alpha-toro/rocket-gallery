--------------------
RocketGallery
--------------------
Author: Wayne Roddy <wayne@rocketcitydigital.com>
--------------------

An Image Gallery Manager for MODx Revolution.

View the quick start on GitHub: http://github.com/josht/faqMan/

Feel free to suggest ideas/improvements/bugs on GitHub:
http://github.com/josht/faqMan/issues


--------------------
Copyright Information

RocketGallery is distributed as GPL.

RocketGallery was built from a FaqMan fork. http://github.com/josht/faqMan/
